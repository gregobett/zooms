@extends('layouts.home')



@section('content')	

@livewireStyles

<div> <livewire:faculty-table></div>


@livewireScripts

@endsection