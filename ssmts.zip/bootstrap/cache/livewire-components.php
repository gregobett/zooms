<?php return array (
  'faculty-table' => 'App\\Http\\Livewire\\FacultyTable',
  'students-table' => 'App\\Http\\Livewire\\StudentsTable',
);