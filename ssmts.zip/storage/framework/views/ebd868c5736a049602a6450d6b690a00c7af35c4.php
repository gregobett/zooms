<?php echo e($slot); ?>

<?php /**PATH C:\Users\gioku\OneDrive\Desktop\school_portal\school-portal\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>