



<?php $__env->startSection('content'); ?>	

<?php echo \Livewire\Livewire::styles(); ?>


<div> <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('students-table', [])->html();
} elseif ($_instance->childHasBeenRendered('XrcE6NG')) {
    $componentId = $_instance->getRenderedChildComponentId('XrcE6NG');
    $componentTag = $_instance->getRenderedChildComponentTagName('XrcE6NG');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('XrcE6NG');
} else {
    $response = \Livewire\Livewire::mount('students-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('XrcE6NG', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></div>



<?php echo \Livewire\Livewire::scripts(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\gioku\OneDrive\Desktop\school_portal\school-portal\resources\views/pages/faculty/student-all-faculty.blade.php ENDPATH**/ ?>