<?php $__env->startSection('content'); ?>

    <?php $__currentLoopData = $querys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $query): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="p-10 flex flex-row bg-gray-200 dark:bg-gray-800 mb-8 rounded-md shadow-xl ml-8 mr-8 mt-8" >
      <!--Card 1-->
      <div class=" w-full lg:max-w-full items-center">
         
              <p class="text-gray-900 dark:text-gray-100 font-semibold text-xl"><?php echo e($query->title); ?></p>
  
              <p class="text-gray-800 dark:text-gray-300 font-normal text-base my-2 "><?php echo e($query->message); ?></p>
  
              <div class="flex justify-center">
                <img src="<?php echo e(url('uploads/announcement/'.$query->photo)); ?>" alt="announcement photo" class="shadow-xl">
              </div>
  
      </div>
    </div>
    <hr class="mb-5 text-gray-900">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        <?php echo $__env->yieldContent('content'); ?>
    
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\gioku\OneDrive\Desktop\school_portal\school-portal\resources\views/view-announcement.blade.php ENDPATH**/ ?>