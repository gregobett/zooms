<svg viewBox="0 0 40 40" ="#A855F7" xmlns="http://www.w3.org/2000/svg" {{ $attributes }}>
   
      <img src="{{asset('/images/logo.webp')}}" alt="logo" width="250px" class="hidden xl:block ">
</svg>
     

  