
@extends('layouts.home')
@section('content')	

      

        @livewireStyles
          <div class="form-item w-full"> <livewire:student-goal></div>
        @livewireScripts

@endsection

   

