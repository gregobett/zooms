@extends('layouts.home')



@section('content')	

@livewireStyles

<div> <livewire:students-table></div>


@livewireScripts

@endsection