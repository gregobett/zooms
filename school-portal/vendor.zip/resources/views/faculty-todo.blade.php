

@extends('layouts.home')
@section('content')



    @livewireStyles
        <div class="form-item w-full"> <livewire:todo-faculty></div>
    @livewireScripts


    @endsection