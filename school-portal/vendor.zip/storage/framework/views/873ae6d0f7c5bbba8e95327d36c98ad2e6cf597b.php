<main class="flex flex-col items-center flex-1 px-4 pt-6 sm:justify-center">
    <div>
        
    </div>

    <div class="w-full px-6 py-4 my-6 overflow-hidden bg-white  rounded-md shadow-md sm:max-w-md dark:bg-dark-eval-1">
        <?php echo e($slot); ?>

    </div>
</main><?php /**PATH C:\Users\gioku\OneDrive\Desktop\tinhs-portal\school-portal\resources\views/components/auth-card.blade.php ENDPATH**/ ?>