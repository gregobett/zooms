


<?php $__env->startSection('content'); ?>



    <?php echo \Livewire\Livewire::styles(); ?>

        <div class="form-item w-full"> <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('todo-faculty', [])->html();
} elseif ($_instance->childHasBeenRendered('cX7zZDA')) {
    $componentId = $_instance->getRenderedChildComponentId('cX7zZDA');
    $componentTag = $_instance->getRenderedChildComponentTagName('cX7zZDA');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('cX7zZDA');
} else {
    $response = \Livewire\Livewire::mount('todo-faculty', []);
    $html = $response->html();
    $_instance->logRenderedChild('cX7zZDA', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></div>
    <?php echo \Livewire\Livewire::scripts(); ?>



    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\gioku\OneDrive\Desktop\tinhs-portal\school-portal\resources\views/faculty-todo.blade.php ENDPATH**/ ?>