<div class="flex flex-col lg:flex-row  gap-x-4  md:mb-2 ">

    <div class="form-item w-full">
        <label for="grade" class="text-md">Grade</label>

        <select wire:model="selectedGrade" class="w-full appearance-none text-black mb-4 rounded shadow py-1  focus:outline-none focus:shadow-outline focus:border-red-200 dark:bg-gray-400  uppercase" id="grade" name="grade" required>
            <option value="" selected>Choose</option>
            <?php $__currentLoopData = $grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($grade->id); ?>" <?php if($selectedGrade == $grade->id): ?> <?php echo e('selected'); ?> <?php endif; ?>><?php echo e($grade->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

    </div>

    <div class="form-item w-full">
        <label for="section" class="text-md">Section</label>

        <select wire:model="selectedSection" class="w-full appearance-none text-black  md:mb-2 rounded shadow py-1 focus:outline-none focus:shadow-outline focus:border-blue-200 dark:bg-gray-400  uppercase" id="section" name="section" required>
            <option value="" selected>Choose</option>
            <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($section->name); ?>" <?php if($selectedSection == $section->name): ?> <?php echo e('selected'); ?> <?php endif; ?>><?php echo e($section->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

    </div>
</div>
<?php /**PATH C:\Users\gioku\OneDrive\Desktop\tinhs-portal\school-portal\resources\views/livewire/gradesectiondropdown.blade.php ENDPATH**/ ?>