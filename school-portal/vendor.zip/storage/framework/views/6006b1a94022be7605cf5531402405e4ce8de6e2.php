<svg viewBox="0 0 40 40" ="#A855F7" xmlns="http://www.w3.org/2000/svg" <?php echo e($attributes); ?>>
   
      <img src="<?php echo e(asset('/images/logo.webp')); ?>" alt="logo" width="250px" class="hidden xl:block ">
</svg>
     

  <?php /**PATH C:\Users\gioku\OneDrive\Desktop\tinhs-portal\school-portal\resources\views/components/application-logo.blade.php ENDPATH**/ ?>