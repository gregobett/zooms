

<?php $__env->startSection('content'); ?>	

      

        <?php echo \Livewire\Livewire::styles(); ?>

          <div class="form-item w-full"> <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('student-goal', [])->html();
} elseif ($_instance->childHasBeenRendered('svqfVut')) {
    $componentId = $_instance->getRenderedChildComponentId('svqfVut');
    $componentTag = $_instance->getRenderedChildComponentTagName('svqfVut');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('svqfVut');
} else {
    $response = \Livewire\Livewire::mount('student-goal', []);
    $html = $response->html();
    $_instance->logRenderedChild('svqfVut', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></div>
        <?php echo \Livewire\Livewire::scripts(); ?>


<?php $__env->stopSection(); ?>

   


<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\gioku\OneDrive\Desktop\tinhs-portal\school-portal\resources\views/dashboard.blade.php ENDPATH**/ ?>