

<?php $__env->startSection('content'); ?>	





    <?php if($data->grade === '11' || $data->grade === '12' ): ?>


        <?php echo \Livewire\Livewire::styles(); ?>

            <div> <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('average-senior', [])->html();
} elseif ($_instance->childHasBeenRendered('yCm0ESm')) {
    $componentId = $_instance->getRenderedChildComponentId('yCm0ESm');
    $componentTag = $_instance->getRenderedChildComponentTagName('yCm0ESm');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('yCm0ESm');
} else {
    $response = \Livewire\Livewire::mount('average-senior', []);
    $html = $response->html();
    $_instance->logRenderedChild('yCm0ESm', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></div>
        <?php echo \Livewire\Livewire::scripts(); ?>


    <?php else: ?>

        <?php echo \Livewire\Livewire::styles(); ?>

            <div> <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('average', [])->html();
} elseif ($_instance->childHasBeenRendered('CSMXyR3')) {
    $componentId = $_instance->getRenderedChildComponentId('CSMXyR3');
    $componentTag = $_instance->getRenderedChildComponentTagName('CSMXyR3');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('CSMXyR3');
} else {
    $response = \Livewire\Livewire::mount('average', []);
    $html = $response->html();
    $_instance->logRenderedChild('CSMXyR3', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></div>
        <?php echo \Livewire\Livewire::scripts(); ?>


        <?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\gioku\OneDrive\Desktop\tinhs-portal\school-portal\resources\views/pages/student/ave.blade.php ENDPATH**/ ?>