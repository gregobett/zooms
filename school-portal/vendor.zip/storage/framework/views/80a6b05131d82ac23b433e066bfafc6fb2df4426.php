

<?php $__env->startSection('content'); ?>	


        <?php echo \Livewire\Livewire::styles(); ?>

          <div class="form-item w-full"> <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('total-students', [])->html();
} elseif ($_instance->childHasBeenRendered('iJAZpgc')) {
    $componentId = $_instance->getRenderedChildComponentId('iJAZpgc');
    $componentTag = $_instance->getRenderedChildComponentTagName('iJAZpgc');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('iJAZpgc');
} else {
    $response = \Livewire\Livewire::mount('total-students', []);
    $html = $response->html();
    $_instance->logRenderedChild('iJAZpgc', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></div>
        <?php echo \Livewire\Livewire::scripts(); ?>


        <?php echo \Livewire\Livewire::styles(); ?>

          <div class="form-item w-full"> <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('faculty-facts', [])->html();
} elseif ($_instance->childHasBeenRendered('YUc1MWV')) {
    $componentId = $_instance->getRenderedChildComponentId('YUc1MWV');
    $componentTag = $_instance->getRenderedChildComponentTagName('YUc1MWV');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('YUc1MWV');
} else {
    $response = \Livewire\Livewire::mount('faculty-facts', []);
    $html = $response->html();
    $_instance->logRenderedChild('YUc1MWV', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></div>
        <?php echo \Livewire\Livewire::scripts(); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\gioku\OneDrive\Desktop\tinhs-portal\school-portal\resources\views/faculty-dashboard.blade.php ENDPATH**/ ?>