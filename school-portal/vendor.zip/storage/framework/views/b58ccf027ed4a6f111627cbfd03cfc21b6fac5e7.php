



<?php $__env->startSection('content'); ?>	

<?php echo \Livewire\Livewire::styles(); ?>


<div> <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('faculty-table', [])->html();
} elseif ($_instance->childHasBeenRendered('OMpyIFp')) {
    $componentId = $_instance->getRenderedChildComponentId('OMpyIFp');
    $componentTag = $_instance->getRenderedChildComponentTagName('OMpyIFp');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('OMpyIFp');
} else {
    $response = \Livewire\Livewire::mount('faculty-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('OMpyIFp', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></div>


<?php echo \Livewire\Livewire::scripts(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\gioku\OneDrive\Desktop\tinhs-portal\school-portal\resources\views/pages/faculty/faculty-all-list.blade.php ENDPATH**/ ?>