<?php echo e($slot); ?>

<?php /**PATH C:\Users\gioku\OneDrive\Desktop\tinhs-portal\school-portal\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>